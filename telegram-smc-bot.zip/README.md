# Telegram SMC Bot

A Smart Money Concepts (SMC) crypto signal bot using Telegram.

## Features
- Sends SMC-based signals
- 3-minute timeframe
- Runs on Railway
